﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace U321218.Models
{
    public class ModelServices: IDisposable
    {

        private readonly SUNATEntities db = new SUNATEntities();

        public IEnumerable<tPago> ObtenerPagos()
        {
            return db.tPagos.ToList();
        }


        public IEnumerable<tPago> BuscarPagos(String pRuc)
        {
            IEnumerable<tPago> query = db.tPagos;
            query = query.Where(p => p.varRuc.Equals(pRuc));
            return query.ToList();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}