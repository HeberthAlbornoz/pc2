﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using U321218.Models;

namespace U321218.Controllers
{
    public class tPagosController : Controller
    {

        public ActionResult Index()
        {
            var datos = new ModelServices().ObtenerPagos();
            return View(datos);
        }

        public ActionResult BuscaPorRuc(String pRuc)
        {
            var datos = new ModelServices().BuscarPagos(pRuc);
            return View(datos);        
        }

    }
}
